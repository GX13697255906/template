//package com.gx.client.websocket.server;
//
//import cn.hutool.core.date.DateUtil;
//import com.gx.client.constants.Constants;
//import io.netty.bootstrap.ServerBootstrap;
//import io.netty.channel.*;
//import io.netty.channel.nio.NioEventLoopGroup;
//import io.netty.channel.socket.SocketChannel;
//import io.netty.channel.socket.nio.NioServerSocketChannel;
//import io.netty.handler.codec.http.HttpObjectAggregator;
//import io.netty.handler.codec.http.HttpServerCodec;
//import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
//import io.netty.handler.logging.LogLevel;
//import io.netty.handler.logging.LoggingHandler;
//import io.netty.handler.stream.ChunkedWriteHandler;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.stereotype.Service;
//
//import java.net.InetSocketAddress;
//import java.util.Date;
//
///**
// * netty 服务端
// *
// * @author guoxun
// */
//@Slf4j
//@Service
//public class WebSocketServer {
//
//    private static void initWebScoket() {
//        EventLoopGroup bossGroup = new NioEventLoopGroup();
//        EventLoopGroup wokerGroup = new NioEventLoopGroup();
//        try {
//            ServerBootstrap serverBootstrap = new ServerBootstrap();
//            serverBootstrap
//                    .group(bossGroup, wokerGroup)
//                    .channel(NioServerSocketChannel.class)
//                    .handler(new LoggingHandler(LogLevel.INFO))
//                    .option(ChannelOption.SO_KEEPALIVE, true)
//                    .childHandler(new ChannelInitializer<SocketChannel>() {
//                        @Override
//                        protected void initChannel(SocketChannel socketChannel) throws Exception {
//                            ChannelPipeline pipeline = socketChannel.pipeline();
//                            //websocket协议本身是基于http协议的，所以这边也要使用http解编码器
//                            pipeline.addLast(new HttpServerCodec());
//                            //以块的方式来写的处理器
//                            pipeline.addLast(new ChunkedWriteHandler());
//                            //netty是基于分段请求的，HttpObjectAggregator的作用是将请求分段再聚合,参数是聚合字节的最大长度
//                            pipeline.addLast(new HttpObjectAggregator(1024 * 1024 * 1024));
//                            //ws://localhost:8899/ws
//                            pipeline.addLast(new WebSocketServerProtocolHandler("/ws"));
//                            //websocket定义了传递数据的6中frame类型
//                            pipeline.addLast(new WebSocketHandle());
//                        }
//                    });
//
//            ChannelFuture channelFuture = serverBootstrap
//                    .bind(new InetSocketAddress(8899))
//                    .sync();
//
//            channelFuture
//                    .channel()
//                    .closeFuture()
//                    .sync();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } finally {
//            bossGroup.shutdownGracefully();
//            wokerGroup.shutdownGracefully();
//        }
//    }
//}