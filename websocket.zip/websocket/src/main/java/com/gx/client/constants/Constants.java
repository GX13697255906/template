package com.gx.client.constants;

public class Constants {

    public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static String host = "127.0.0.1";
    public static Integer port = 8080;
    public static String ClientIdle = "clientIdle";
    public static String ServerIdle = "serverIdle";
    public static String ping = "ping";
    public static String pong = "pong";

}
