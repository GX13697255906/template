import Vue from 'vue';
import iView from 'iview';
import VueRouter from 'vue-router';
import axios from 'axios';
import Vuex from 'vuex';

import Cookies from 'js-cookie';