import Env from './env';

let config = {
    env: Env
};
export default config;